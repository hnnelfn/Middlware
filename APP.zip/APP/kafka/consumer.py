from kafka import KafkaConsumer
import json
import os

consumer = KafkaConsumer(
    'chat',
    bootstrap_servers='localhost:9092',
    value_deserializer=lambda m: json.loads(m.decode('utf-8'))
)

print("Listening for messages...\n")

for message in consumer:
    msg = message.value
    msg_type = msg.get('type')
    to = msg.get('to')

    print(f"\n>> Message to: {to}")
    
    if msg_type == 'text':
        print(f"Text: {msg['content']}")

    elif msg_type in ['file', 'image']:
        filename = f"received_{msg['filename']}"
        with open(filename, 'wb') as f:
            f.write(msg['content'].encode('latin1'))  # decode back to binary
        print(f"{msg_type.title()} received and saved as {filename}")

    print("-" * 30)
