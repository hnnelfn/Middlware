from kafka import KafkaProducer
import json
import os

producer = KafkaProducer(
    bootstrap_servers='localhost:9092',
    value_serializer=lambda m: json.dumps(m).encode('utf-8')
)

print("Welcome to the Kafka Chat Producer!")

while True:
    msg_type = input("Type (text/file/image): ").strip().lower()
    to = input("To (user or group): ").strip()
    
    if msg_type == 'text':
        message = input("Enter your message: ")
        data = {
            'type': 'text',
            'to': to,
            'content': message
        }

    elif msg_type in ['file', 'image']:
        file_path = input("Enter path to file/image: ").strip()
        if not os.path.isfile(file_path):
            print("File not found.")
            continue
        with open(file_path, 'rb') as f:
            content = f.read()
        data = {
            'type': msg_type,
            'to': to,
            'filename': os.path.basename(file_path),
            'content': content.decode('latin1')  # encode binary as string
        }
    else:
        print("Invalid message type.")
        continue

    producer.send('chat', value=data)
    print("Message sent!")
