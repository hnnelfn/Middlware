from flask import Flask, render_template, request, jsonify
from kafka import KafkaProducer
import base64
import os

app = Flask(__name__)
producer = KafkaProducer(bootstrap_servers='localhost:9092')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/send', methods=['POST'])
def send():
    msg_type = request.form['type']
    to = request.form['to']

    if msg_type == 'text':
        message = {
            'to': to,
            'type': 'text',
            'content': request.form['message']
        }
    elif msg_type in ['file', 'image']:
        file = request.files['file']
        data = file.read()
        encoded = base64.b64encode(data).decode('utf-8')

        message = {
            'to': to,
            'type': msg_type,
            'filename': file.filename,
            'content': encoded
        }
    else:
        return jsonify({'status': 'error', 'message': 'Invalid type'})

    import json
    producer.send('chat', json.dumps(message).encode('utf-8'))
    return jsonify({'status': 'sent'})

# 🔥 Add this part:
if __name__ == '__main__':
    app.run(debug=True)
